<?php
header('Content-Type:application/json');
//连接mongodb的数据库服务
// $url = "mongodb://127.0.0.1:27017";
$url="mongodb://root:BLufMxBtg9HBPYQZVxayjHmhN1id30asYwiDMRcJ@qpstricmynqo.mongodb.sae.sina.com.cn:10161";
$conn = new MongoClient($url);

//指定操作的数据库名称
$db = $conn->db_articles;

?>