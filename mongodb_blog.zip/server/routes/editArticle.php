<?php
    require_once('../controllers/article.php');
    editArticle();
?>