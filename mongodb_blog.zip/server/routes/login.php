<?php
    require_once('../controllers/user.php');
    login();
?>