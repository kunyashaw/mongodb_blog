<?php
    require_once('../controllers/article.php');
    viewArticle();
?>